package com.mphasis.mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class productmain {
	public static void main(String[] args) {
		Configuration c=new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory factory=c.buildSessionFactory();
		Session session=factory.openSession();
		Transaction t=session.beginTransaction();
		product p=new product();
		p.setBname("pen");
		p.setBrate(100);
		session.persist(p);
		t.commit();
		session.close();
		System.out.println("Success");
		
	}

}
	

	