package com.mphasis.mypack;
import javax.persistence.*;

@Entity
@Table(name="prod")
public class product {
	@Id @GeneratedValue(generator="increment")
	private int bcode;
	@Column(name="pname")
	private String bname;
	@Column(name="prate")
	private int brate;
	public int getBcode() {
		return bcode;
	}
	public void setBcode(int bcode) {
		this.bcode = bcode;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public int getBrate() {
		return brate;
	}
	public void setBrate(int brate) {
		this.brate = brate;
	}

}

