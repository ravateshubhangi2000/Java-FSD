package selenium.practiceproject5phase5;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * WebDriver operations on various web elements including handling pop-ups, new tabs, and new windows
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
        // Set up WebDriver for Chrome
        WebDriverManager.chromedriver().setup();
        // Create a new instance of the ChromeDriver
        WebDriver wd=new ChromeDriver();
        // Maximize the browser window
        wd.manage().window().maximize();
        
        // Navigate to the specified URL
        wd.get("https://www.amazon.in/");
        // Supply data to the search box
        wd.findElement(By.id("twotabsearchtextbox")).sendKeys("samsung");
        // Click on the search button
        wd.findElement(By.xpath("//*[@id=\"nav-search-submit-button\"]")).click();
        
        // Step 1.5.1: Handling External pop-ups
        // To click on ‘OK’ button in pop-up
        wd.switchTo().alert().accept();
        // To click on ‘Cancel’ button in pop-up
        wd.switchTo().alert().dismiss();
        // To capture the alert message
        String alertMessage = wd.switchTo().alert().getText();
        System.out.println("Alert Message: " + alertMessage);
        // To enter information in the alert
        wd.switchTo().alert().sendKeys("Text");
        // To exit from the popup
        wd.switchTo().alert().accept();
        
        // Step 1.5.2: Handling new Tabs and new Window
        // Opening new tab
        wd.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
        // Opening new Window
        wd.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "w");
        
        // Close browser
        Thread.sleep(2000);
        wd.quit();
    }
}
