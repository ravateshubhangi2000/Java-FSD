package practice_project8;
class Animals
{
	void sounds()
	{
		System.out.println("Animal makes a sounds");
	}
}
class Cat extends Animals
{
	void sounds()
	{
		System.out.println("cat sounds mewmew");
	}

}
public class Inheritance {

	public static void main(String[] args) {
		Cat c=new Cat();
		c.sounds();
	}

}
