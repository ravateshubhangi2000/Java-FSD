package practice_project8;
class BikeDemo {
    String brand;
    String color;

    public void display() {
        System.out.println("Brand: " + brand);
        System.out.println("color: " + color);
    }
}

public class Bike {

	public static void main(String[] args) {
		 BikeDemo b = new BikeDemo();
	        b.brand = "R15";
	        b.color = "Red";
	        b.display();

	}

}
