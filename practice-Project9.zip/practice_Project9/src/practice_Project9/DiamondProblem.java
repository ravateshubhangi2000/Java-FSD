package practice_Project9;

public class DiamondProblem implements First,Second {
	public void show() 
	{  
		First.super.show(); 
		Second.super.show(); 
	} 


	public static void main(String[] args) {
		DiamondProblem obj = new DiamondProblem(); 
		obj.show(); 

	}
}


