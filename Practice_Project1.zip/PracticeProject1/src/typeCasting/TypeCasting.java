package typeCasting;

public class TypeCasting {

	public static void main(String[] args) {
		System.out.println("Implicit Typecasting :");
		char a='A';
		System.out.println("Value of a is :" +a);
		int b=a;
		System.out.println("value of b is :" +b);
		float c=a;
		System.out.println("value of c is :" +c);
		long d=a;
		System.out.println("value of d is :" +d);
		double e=a;
		System.out.println("value of e is :" +e);
		System.out.println("\n");
		System.out.println("Explicit typecasting :");	
		double x=55.9;
		int y=(int)x;
		System.out.println("value of x is: "+x);
		System.out.println("value of y is: "+y);
		

	}

}
