// app.module.ts

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component'; // Make sure to import your components

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    // ... other components
  ],
  imports: [
    BrowserModule,
    RouterModule,
    // ... other modules
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
