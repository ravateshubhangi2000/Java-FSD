package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommercePracticeProject13Application {

	public static void main(String[] args) {
		SpringApplication.run(EcommercePracticeProject13Application.class, args);
	}

}
