package pack2;
import pack1.*;
public class AccessModifiers4 {

	public static void main(String[] args)
	{		
			PublicAccessModifiers obj = new PublicAccessModifiers(); 
	        obj.display();  


	}

}
