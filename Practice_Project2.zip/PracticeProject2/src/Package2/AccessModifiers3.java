package Package2;
import package1.*;
public class AccessModifiers3 extends ProtectedAccessModifiers {

	public static void main(String[] args) 
	{
		AccessModifiers3 obj = new AccessModifiers3();   
		obj.display(); 


	}

}
