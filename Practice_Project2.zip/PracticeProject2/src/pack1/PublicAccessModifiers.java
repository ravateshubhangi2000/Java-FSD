package pack1;

public class PublicAccessModifiers
{
	public void display() 
	{
		System.out.println("Public Access modifiers");
	}

}
