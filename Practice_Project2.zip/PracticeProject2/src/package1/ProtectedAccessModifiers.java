package package1;

public class ProtectedAccessModifiers {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

}
