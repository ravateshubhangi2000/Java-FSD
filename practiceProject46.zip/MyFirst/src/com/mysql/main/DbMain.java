package com.mysql.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.mysql.dao.ProductDAO_Impl;
import com.mysql.pojo.Product;
import com.mysql.util.DbUtil;

public class DbMain {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.dbConn();

		if(con!=null) {
			System.out.println("dB connection is established successfully....");
		}

		Scanner sc=new Scanner(System.in);
		//working data
		ProductDAO_Impl dao=null;
		Product product=null;
		while(true) {
			System.out.println("Menu \n 1. add Product \n 2. Delete product \n 3. update product \n  4. Retrive product \n 5.exit");
			System.out.println("enter the choice ");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:product=new Product();
			System.out.println("enter product id ");
			product.setPid(sc.nextInt());
			System.out.println("enter product name");
			product.setPname(sc.next());
			System.out.println("enter product cost");
			product.setCost(sc.nextInt());
			dao=new ProductDAO_Impl();
			if(dao.addProduct(product)>0) {
				System.out.println("product got inserted with details "+product);
			}
			break;

			case 2:
				System.out.println("enter product id");

				int id=sc.nextInt();

				dao=new ProductDAO_Impl();
				
				if(dao.deleteProduct(id)>0) {
					System.out.println("product got deleted with details "+id);
				}

				break;



			case 3:  
				dao=new ProductDAO_Impl();
				List<Product> productlist=dao.selectProducts();
				for(Product products:productlist) {
					System.out.println(products);
				}
				break;
			case 5:System.exit(0);
			break;
			}
		}
	}

	// TODO Auto-generated method stub

}

