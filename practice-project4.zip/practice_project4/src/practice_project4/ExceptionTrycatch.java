package practice_project4;

public class ExceptionTrycatch {

	public static void main(String[] args) {
		try  
		{  
			int data=10/0; //it throws exception   
		}  

		catch(Exception e)  
		{  
			System.out.println(e);  
		}  
		System.out.println("Exception Handling");  
	}  


}


