package practice_project7;
import java.io.FileWriter;
import java.io.IOException;
public class Update {

	public static void main(String[] args) {
	        try {
	            FileWriter writer = new FileWriter("hello.txt", true);
	            writer.write("This is an update to the file.");
	            writer.close();
	            System.out.println("File updated successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }
	    }
	}


