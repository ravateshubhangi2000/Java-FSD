package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class DatabaseServlet {
public static void main(String[] args) throws SQLException {
	

    String JDBC_URL = "jdbc:mysql://localhost:3306/db4";
    String USER = "root";
    String PASSWORD = "Shubhangi@1234";

       Connection connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             Scanner sc=new Scanner(System.in);
             System.out.println("Enter the your choice: ");
             System.out.println("1) Create \n 2) Use\n 3)Drop ");
             int ch=sc.nextInt();

            switch (ch) {
                case 1:
                    String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS new_database";
                    statement.executeUpdate(createDatabaseQuery);
                    System.out.println("Database created successfully");
                    break;

                case 2:
                    String useDatabaseQuery = "USE books";
                    statement.executeUpdate(useDatabaseQuery);
                    System.out.println("Using new_database");
                    break;

                case 3:
                    String dropDatabaseQuery = "DROP DATABASE IF EXISTS new_database";
                    statement.executeUpdate(dropDatabaseQuery);
                    System.out.println("Database dropped successfully");
                    break;

                default:
                	 System.out.println("Invalid operation");
            

            }
    }
}
