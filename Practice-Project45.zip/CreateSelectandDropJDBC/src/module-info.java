/**
 * 
 */
/**
 * 
 */
module CreateSelectandDropJDBC {
	requires java.sql;
}