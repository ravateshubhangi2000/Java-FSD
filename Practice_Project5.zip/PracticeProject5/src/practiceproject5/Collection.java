package practiceproject5;
import java.util.*;

public class Collection 
{

	public static void main(String[] args) 
	{
	
		System.out.println("ArrayList is:"); //create Arraylist
		ArrayList<String> city=new ArrayList<String>();   
		city.add("Nashik");
		city.add("Pune");    	   
		System.out.println(city);  

		System.out.println("\n");
		System.out.println("Vector is:"); //create vector
		Vector<Integer> vec = new Vector();
		vec.addElement(15); 
		vec.addElement(30); 
		System.out.println(vec);

		System.out.println("\n");
		System.out.println("LinkedList is:"); //create linkedlist
		LinkedList<String> names=new LinkedList<String>();  
		names.add("Alex");  
		names.add("John");  	      
		Iterator<String> itr=names.iterator();  
		while(itr.hasNext())
		{  
			System.out.println(itr.next());  
			System.out.println("\n");
			System.out.println("HashSet is: "); //create hashset
			HashSet<Integer> set=new HashSet<Integer>();  
			set.add(101);  
			set.add(103);  
			set.add(102);
			set.add(104);
			System.out.println(set);
			
			System.out.println("\n");
			System.out.println("LinkedHashSet is:"); //create linkedhashset
			LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
			set2.add(10);  
			set2.add(20);  
			set2.add(30);
			set2.add(40);	       
			System.out.println(set2);
		} 
	}  
}




