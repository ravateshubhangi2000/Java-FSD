package practice_Project3;

public class Synchronization {

	public static void main(String[] args) {

		Sender snd = new Sender(); 
		ThreadedSend thread1 = new ThreadedSend( " Hi " , snd ); 
		ThreadedSend thread2 = new ThreadedSend( " Bye " , snd ); 
		thread1.start(); 
		thread2.start(); 
		try
		{ 
			thread1.join(); 
			thread2.join(); 
		} 
		catch(Exception e) 
		{ 
			System.out.println("Interrupted"); 
		} 
	} 

}


