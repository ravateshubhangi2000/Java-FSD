package module5;

public class BoxMain
{

	public static void main(String[] args) 
	{
		Box box=new Box(10,20,30);


	}

}
