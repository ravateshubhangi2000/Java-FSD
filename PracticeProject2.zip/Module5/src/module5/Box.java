package module5;

public class Box 
{

	/*this method  find the volume of box*/
	Box(double l,double b, double h)
	{
		double volume=l*b*h;
		System.out.println("volume of box is -->"+volume);
	}
}