package practice_Project1;
public class DemoThread extends Thread
{
	public void run()
	{
		System.out.println("thread started running.....");
	}
	public static void main(String[] args) 
	{
			DemoThread t = new  DemoThread();
			t.start();		

	}

}
